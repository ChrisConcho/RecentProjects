package parseOrders;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class Data{

	@SerializedName("name")
	@Expose
	private String name = null;
	@SerializedName("address")
	@Expose
	private String address = null;
	@SerializedName("latitude")
	@Expose
	private Double latitude = null;
	@SerializedName("longitude")
	@Expose
	private Double longitude;
	@SerializedName("menu")
	@Expose
	private ArrayList<String> menu = null;
	@SerializedName("drivers")
	@Expose
	private Integer drivers = null;
	public Vector<Driver> driver = new Vector<Driver>();
	public Vector<Orders> orders = new Vector<Orders>();

	
	private double Distance= 0;
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public ArrayList<String> getMenu() {
		return menu;
	}

	public void setMenu(ArrayList<String> menu) {
		this.menu = menu;
	}
	
	public Double getDistance() {
		return Distance;
	}
	
	public void SetDistance(double x) {
		Distance = x;
	}
	public Boolean MissParam() {
		if (this.menu.isEmpty() || this.getLatitude() == null || this.getAddress() == null || this.getLongitude()== null || this.getName() == null) {
			return false;
		}
		else {
			return true;
		}
	}

	public Integer getDrivers() {
		return drivers;
	}

	public void setDrivers(Integer drivers) {
		this.drivers = drivers;
	}
}