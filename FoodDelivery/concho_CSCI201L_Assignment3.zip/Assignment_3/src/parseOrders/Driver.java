package parseOrders;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Driver extends Thread {
	private static ReentrantLock DriverLock;
	public Data company;
	public Orders order;
	public Vector<Orders> orders;
	public Vector<Orders> SharedOrders;
	public Socket socks;
	public ObjectOutputStream oos;
	public double CurrentLat;
	public double CurrentLong;
	public double HomeLong;
	public double HomeLat;
	public volatile boolean isasleep = true;
	public volatile boolean started = false;
	public volatile boolean keepgoin = false;
	public volatile boolean stop = false;
	public static double CalcMile(double lat1, double long1, double lat2,double long2) {
		double lat10 = Math.toRadians(lat1);
		double lat20 = Math.toRadians(lat2);
		double long10 = Math.toRadians(long1);
		double long20 = Math.toRadians(long2);
		double d = 3963.0 * Math.acos((Math.sin(lat10) * Math.sin(lat20)) + Math.cos(lat10) * Math.cos(lat20) * Math.cos(long10 - long20));
		return d;
	}

	public Orders findShortest( Vector<Orders> orders) {
		if ( orders.isEmpty()) {
			System.out.println("No Elements!");
		}
		Orders sol = orders.firstElement();
		for ( Orders it : orders) { // grab lat and long when making order. 
			if (CalcMile(CurrentLat, CurrentLong, sol.latitude, sol.longitude) > CalcMile(CurrentLat, CurrentLong, it.latitude, it.longitude)) {
				sol = it;
			}
		}
		return sol;
	};
	
	public Driver(double hlat, double hlong, ObjectOutputStream os) {
		HomeLat = hlat;
		HomeLong = hlong;
		oos= os;
		SharedOrders = null;
		CurrentLat = HomeLat;
		CurrentLong = HomeLong;
		DriverLock = new ReentrantLock();
		DriverLock.newCondition();
	}
	public void wakeUpDriver(Vector<Orders> x) {
		try {
		SharedOrders = x;
		isasleep = false;
		started = false;
		for ( Orders a : SharedOrders) {
			oos.writeObject(Util.util_message()+a.name());
		}
		keepgoin = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		}
	}
	public void MakeDelivery() {
		try {
			Orders current_order = findShortest(orders);
			if (started&& CurrentLat!= current_order.latitude && CurrentLong != current_order.longitude) {
				String message = ("Continuing deliver to "+current_order.Company+ ".");
				oos.writeObject(Util.util_message()+message);
			}
			Thread.sleep((long)(1000*CalcMile(CurrentLat, CurrentLong, current_order.latitude, current_order.longitude)));
			CurrentLat = current_order.latitude;
			CurrentLong = current_order.longitude;
			String message = ("Finished Delivery of " + current_order.food + " from " +current_order.Company +"!");
			oos.writeObject(Util.util_message()+message);
			orders.remove(orders.indexOf(current_order));
			started = true;
		}catch (InterruptedException ie) {
			System.out.println("ie out for delivery" + ie.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		}
		
	}
	public void GoHome() {
		try {
			
			String message = ("Finished " + 
					"all deliveries, " + 
					"returning back to " + 
					"HQ.");
			oos.writeObject(Util.util_message()+message);

			Thread.sleep((long)(1000*CalcMile(CurrentLat,CurrentLong,HomeLat,HomeLong)));
			message = ("Returned to HQ.");
			oos.writeObject(Util.util_message()+message);
			isasleep = true;
			started = false;
			keepgoin = false;
		}catch (InterruptedException ie) {
			System.out.println("ie out for delivery" + ie.getMessage());
		} catch (IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		}
}

public void run() {
			while(!stop) {
				try {
				while(keepgoin) {
							orders = new Vector<Orders>(SharedOrders);
							SharedOrders.clear();
						
							if ( orders != null) {
								while(!orders.isEmpty()) {
									MakeDelivery();
								}
								if(started) {
									GoHome();
									
								}
							}
					}
				}catch( NoSuchElementException e) {
					stop = true;
				}
			}
		}
}

