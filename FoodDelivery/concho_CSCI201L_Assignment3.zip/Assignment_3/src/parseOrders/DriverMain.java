package parseOrders;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class DriverMain {
//	public static Driver driver;
	public static double HomeLat;
	public static double HomeLong;

	public static boolean readyForPickup = true;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Socket s;
		PrintWriter pw;
		BufferedReader br;
		ObjectOutputStream oos;
		ObjectInputStream ois;
		Vector<Orders> deliveries = new Vector<Orders>();
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		System.out.println("Welcome to SalEats v2.0!");
		while (true) {
			System.out.println("Enter the server name: ");
			String host = scan.nextLine();
			System.out.println("Enter the server port: ");
			int port = Integer.parseInt(scan.nextLine());
			String start = ("All drivers");

			try {
				s = new Socket(host, port);

				ois = new ObjectInputStream(s.getInputStream());
				oos = new ObjectOutputStream(s.getOutputStream());
				while (flag) {
					String response = (String) ois.readObject();
					System.out.println(response);
					if (response.contains(start)) {
						flag = false;
						break;
					}

				}

				while (true) {
					String response = (String) ois.readObject();
					System.out.println(response);
					System.out.println();
				}
			} catch (EOFException e) {
				System.exit(0);
			} catch (SocketException e) {
				System.out.println("No more Drivers Needed!");
			} catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Please use the appropriate Host and Port #.");
			}
		}

	}

}