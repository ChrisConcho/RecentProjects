package parseOrders;

import java.io.*;
import java.lang.Math;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
//import java.net.http.HttpClient;
//import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
//import java.net.http.HttpResponse.BodyHandlers;
import java.util.concurrent.locks.ReentrantLock;

import com.google.gson.*;

public class ParseFile2 {
	private static ReentrantLock OrderLock;
	private static Condition MakingDelivery;

	public static double CalcMile(double lat1, double long1, double lat2, double long2) {
		double lat10 = Math.toRadians(lat1);
		double lat20 = Math.toRadians(lat2);
		double long10 = Math.toRadians(long1);
		double long20 = Math.toRadians(long2);
		double d = 3963.0 * Math.acos(
				(Math.sin(lat10) * Math.sin(lat20)) + Math.cos(lat10) * Math.cos(lat20) * Math.cos(long10 - long20));
		return d;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Gson gson = new Gson();
		int ReadFile = 0;
		double lat1 = 34.02116;
		double long1 = -118.287132;
		int driver_number = 0;
		ArrayList<Data> rest = new ArrayList<Data>();
		Vector<Driver> drivers = new Vector<Driver>();
		Vector<Orders> order = new Vector<Orders>();
		Vector<Orders> ordersToDeliver = new Vector<Orders>();
		Vector<Socket> socketarray = new Vector<Socket>();
		Vector<ObjectOutputStream> oos_vect = new Vector<ObjectOutputStream>();
		Vector<ObjectInputStream> ois_vect = new Vector<ObjectInputStream>();
		BufferedReader read = null;
		BufferedReader read2 = null;
		String filename = new String();
		String orders = new String();
		Example date = new Example();
		int temp2 = 0;
		OrderLock = new ReentrantLock();
		MakingDelivery = OrderLock.newCondition();
		ReadFile = 0;
		while (ReadFile == 0) {
			System.out.println("What is the name of the file containing the schedule information?");
			orders = s.nextLine();
			try {
				read2 = new BufferedReader(new FileReader(orders));
				int correct_rest = 0;
				String rest_name = null;
				String line = read2.readLine();
				while (line != null) {
					String[] params = line.split(", ", 3);
					order.add(new Orders(params[0], params[1], params[2]));

					line = read2.readLine();
				}
				ReadFile = 1;
			} catch (FileNotFoundException e) {
				System.out.println("The file " + orders + " could not be found.");
			} catch (NullPointerException e) {
				System.out.println("The file " + orders + " could not be found.");
			} catch (IOException e) {
				System.out.println("The file " + orders + " could not be found.");
			}
		}
		ReadFile = 0;
		while (ReadFile == 0) {
			try {
				System.out.println("What is your latitude? ");
				lat1 = Double.parseDouble(s.nextLine());
				System.out.println("What is your longitude? ");
				long1 = Double.parseDouble(s.nextLine());
				System.out.println("How many drivers do you have?");
				driver_number = Integer.parseInt(s.nextLine());

//	
				ReadFile = 1;
			} catch (NullPointerException e) {
				System.out.println("Please use valid Latitudes, Longitudes, and Drivers!");
			} catch (NumberFormatException e) {
				System.out.println("Please use valid Latitudes, Longitudes, and Drivers!");
			}
			try {
				for (Orders current_order : order) {
					String name = current_order.Company.replaceAll("\\s+", "_");
					String name2 = name.replaceAll("’", "");
					String term = "?term=" + name2;
					String coords = "&latitude=" + lat1 + "&longitude=" + long1;
					String search = "https://api.yelp.com/v3/businesses/search";
					String url = search + term + coords;
					HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();

					// optional default is GET
					connection.setRequestMethod("GET");
					connection.setRequestProperty("Authorization",
							"Bearer sibq5OrsQmtSF9g4-FeCGsXdaiCBS6x_5I9RtBnuy0zlel0iip-YN3JQdCpc2PpqDXDRPgEWz4NJMIG-i5KDDTvkjgbbxut9IEh1bWsPuilhNhFKvhrYISh8gSx5XnYx");

					BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

					int responseCode = connection.getResponseCode();

					String inputLine;
					StringBuffer response = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();

					@SuppressWarnings("deprecation")
					JsonObject jsonObj = new JsonParser().parse(response.toString()).getAsJsonObject();
//				    			
					JsonArray jArr = jsonObj.get("businesses").getAsJsonArray();
//				    			
					JsonObject jEntry = jArr.get(0).getAsJsonObject();
//				    			
					current_order.latitude = jEntry.get("coordinates").getAsJsonObject().get("latitude").getAsDouble();
//				    			    			
					current_order.longitude = jEntry.get("coordinates").getAsJsonObject().get("longitude")
							.getAsDouble();

				}

			} catch (MalformedURLException e) {
				System.out.println("There seems to have been a problem with the Business Name. Please try an appropriate order.");
			} catch (IOException e) {
				System.out.println("There seems to have been a problem with the Business Name. Please try an appropriate order.");
			}
		}

		if (ReadFile == 1) {
			int finished = 0;
			try {
				ServerSocket serverSocket = new ServerSocket(3456);
				System.out.println("Listening on port 9999. Waiting for drivers...");
				for (int i = 0; i < driver_number; ++i) {
					Socket socket = serverSocket.accept();
					socketarray.add(socket);
					ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
					ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
					Driver driver = new Driver(lat1, long1, oos);
					drivers.add(driver);
					oos_vect.add(oos);
					ois_vect.add(ois);

					System.out.println("Connection from " + socket.getInetAddress());
					if (i + 1 == driver_number) {
						for (Socket sck : socketarray) {
							ObjectOutputStream pw = oos_vect.elementAt(socketarray.indexOf(sck));
							pw.writeObject("All drivers have\n" + "arrived!\n" + "Starting service.");
							pw.flush();
						}
						System.out.println("Starting Service!");
					} else {
						for (Socket sck : socketarray) {
							ObjectOutputStream pw = oos_vect.elementAt(socketarray.indexOf(sck));
							pw.writeObject((driver_number - i - 1) + " more driver is\n" + "needed before the\n"
									+ "service can begin.\n" + "Waiting...");
							pw.flush();
						}
						System.out.println("Waiting for " + (driver_number - i - 1) + " driver(s)...");

					}

				}
				boolean drivers_done = false;
				ExecutorService executors = Executors.newCachedThreadPool();
				for ( Driver driver : drivers) {
					executors.execute(driver);
				}
				for (Orders order1 : order) {
					order1.ordersToDeliver = ordersToDeliver;
					executors.execute(order1);

				}

				while (order.size() > finished) {
					if (ordersToDeliver.size() >= 1) {

						
//							

						int Driver_found = 0;
						while (Driver_found == 0) {
							if (ordersToDeliver.lastElement().timestamp != null
									&& ((ordersToDeliver.lastElement().timeTramp <= Util.time()))) {
								for (Driver driver : drivers) {
									if (driver.isasleep) {
										Vector<Orders> temp = new Vector<Orders>(ordersToDeliver);
										finished = finished + ordersToDeliver.size();
										ordersToDeliver.clear();
										driver.wakeUpDriver(temp);
										Driver_found = 1;
										break;
									}
								}
							}
						}
					}
//						
				}
				
				while (!drivers_done) {
					drivers_done = true;
					for (Driver driver : drivers) {
						if (!driver.isasleep) {
							drivers_done = false;
						}
					}
				}
				for (Driver drive : drivers) {
					drive.stop = true;
				}
				System.out.println("All Orders Completed!");
				String message = (Util.util_message()+("All Orders Completed!"));
				for (ObjectOutputStream os : oos_vect) {
					try {
						os.writeObject(message);
						os.close();
					} catch (IOException e) {
						System.exit(0);
					}

				}
				executors.shutdown();
				while (!executors.isTerminated()) {

					Thread.yield();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			System.exit(0);
		}
	}
}
