package parseOrders;

import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Dictionary;

import java.util.Map;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Orders extends Thread implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int makingOrder;
	public String Company;
	public String food;
	public double longitude;
	public double latitude;
	public boolean ReadyForDelivery = false;
	private ReentrantLock OrderLock;
	private Condition MakingDelivery;
	public Vector<Orders> ordersToDeliver;
	public Vector<Driver> drivers;
	public volatile boolean Driver_found = false;
	public String timestamp =null;
	public int timeTramp = 0;
	
	public Orders(String waittime, String Compnay, String food) {
		this.makingOrder = Integer.parseInt(waittime);
		this.Company = Compnay;
		this.food = food;
		OrderLock = new ReentrantLock();
		MakingDelivery = OrderLock.newCondition();
	}
	public String name() {
		return ("Starting Delivery of "+ this.food + " from " + this.Company + "!");
	}
	public void finishingDelivery() {
		try {
			OrderLock.lock();
			MakingDelivery.signal();
		} finally {
			OrderLock.unlock();
		}
	}
	public void run() {
		try {
			Thread.sleep(makingOrder * 1000);
			ReadyForDelivery = true;
			ordersToDeliver.add(this);
			timestamp = Util.util_message();
			timeTramp = Util.time();
		} catch (InterruptedException ie) {
			System.out.println("ie getting haircut: " + ie.getMessage());
		} finally {
			
		}
		
		
	}
}