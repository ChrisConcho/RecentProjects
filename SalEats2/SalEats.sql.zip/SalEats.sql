CREATE DATABASE SalEats;
USE SalEats;
CREATE TABLE Users(
	username VARCHAR(100) PRIMARY KEY NOT NULL,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    favorites VARCHAR(10000) NOT NULL
);
INSERT INTO Users( username , password, email, favorites)
	values ('Chris', '123PASS', 'chris@email.com','');

