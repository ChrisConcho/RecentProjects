package base;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ArrayOfBusiness  {

@SerializedName("businesses")
@Expose
private List<Business> businesses = null;

public List<Business> getBusinesses() {
return businesses;
}

public void setBusinesses(List<Business> businesses) {
this.businesses = businesses;
}

}