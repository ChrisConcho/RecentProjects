package Servlet_package;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import base.ArrayOfBusiness;
import base.Business;
/**
 * Servlet implementation class FavoritesServlet
 */
@WebServlet("/FavoritesServlet")
public class FavoritesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FavoritesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String next = "/details.jsp";
    	Connection conn = null;
    	Statement st = null;
    	PreparedStatement ps = null;
    	PreparedStatement ts = null;
    	ResultSet rs = null;
    	String command = request.getParameter("aJax");
    	String fave_email = request.getParameter("fave_email");
    	System.out.println("Reached Favorite Servlet");
    	System.out.println(fave_email);
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/SalEats?user=root&password=root&serverTimezone=UTC");
			System.out.println("made connection");
		
			st = conn.createStatement();
			
			if( command != null && command.contentEquals("add")) {
				System.out.println("flag1");
				String jsonString = request.getParameter("faveString");
				jsonString = jsonString.replaceAll("\"", "'");
				jsonString = jsonString.replaceAll("&", "u0026");
				String email = (String)request.getParameter("email");
				String out = "UPDATE Users SET favorites = '" +jsonString+"' WHERE email = '"+email+"'";
				System.out.println(out);
				
				ps = conn.prepareStatement("UPDATE Users SET favorites = \"" +jsonString+"\" WHERE email = '"+email+"'");
				ps.executeUpdate();
				System.out.println("Favorite has been updated");
				request.setAttribute("faves",jsonString);
			}
			if(  command != null && command.contentEquals("sub")) {
				System.out.println("flag2");
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				String nameToDelete = request.getParameter("dName");
				String locToDelete = request.getParameter("dLocal");
				nameToDelete = nameToDelete.replaceAll( "&", "u0026");
				nameToDelete = nameToDelete.replaceAll("'", "001");
				locToDelete = locToDelete.replaceAll( "&", "u0026");
				locToDelete = locToDelete.replaceAll("'", "001");
				System.out.println("Name: " +nameToDelete+ "  Location: " + locToDelete);
				System.out.println("SELECT* FROM Users WHERE email = '"+email+"'");
				ps = conn.prepareStatement("SELECT* FROM Users WHERE email = '"+email+"'");
				rs =ps.executeQuery();
				rs.next();
				String jsonString = rs.getString("favorites");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
				for (Business x: theStuff) {
					if(x.getName().contentEquals(nameToDelete)) {
						if(x.getLocation().contentEquals(locToDelete)) {
							theStuff.remove(x);
							break;
						}
					}
				}
				
				busyArray.setBusinesses(theStuff);
				jsonString = gson.toJson(busyArray);
				ts = conn.prepareStatement("UPDATE Users SET favorites = '" + jsonString+"' WHERE email = '" + email + "' ;");
				ts.executeUpdate();
				System.out.println("Business: "+nameToDelete+" has been deleted");
				request.setAttribute("faves",jsonString);
			}
			
			if(command != null && command.contentEquals("A2Z")) {
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				
				
				String jsonString = rs.getString("favorites");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
			}
			if(command != null && command.contentEquals("Z2A")) {
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				
				
				String jsonString = rs.getString("favorites");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
			}
			if(command != null && command.contentEquals("HighRating")) {
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				
				
				String jsonString = rs.getString("favorites");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
			}
			if(command != null && command.contentEquals("LowRating")) {
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				
				
				String jsonString = rs.getString("favorites");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
			}
			if(command != null && command.contentEquals("MostRecent")) {
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				
				String jsonString = rs.getString("favorites");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
			}
			if(command != null && command.contentEquals("LeastRecent")) {
				Gson gson = new Gson();
				String email = (String)request.getParameter("email");
				System.out.println("we are in least recent");
				String jsonString = request.getParameter("jarr");
				jsonString= jsonString.replaceAll("00zxcv1", "'");
				System.out.println(jsonString);
				JsonParser parser = new JsonParser();
				JsonElement je = parser.parse(jsonString);
				JsonArray jarr  = je.getAsJsonArray();
				
				JsonArray leastRecent = new JsonArray();
				for ( int x = jarr.size()-1; x >=0; x--) {
					leastRecent.add(jarr.get(x));
				}
				
				request.setAttribute("json",leastRecent);
				System.out.println(leastRecent);
				next = "/favorites.jsp";
				
			}
			
			if (fave_email != null) {
				System.out.println("flag3");
				next = "/favorites.jsp";
				System.out.println("Going to Favorites");
				Gson gson = new Gson();
				ps = conn.prepareStatement("SELECT* FROM Users WHERE email = '"+fave_email+"'");
				rs= ps.executeQuery();
				rs.next();
				String jsonString = rs.getString("favorites");
				String username = rs.getString("username");
				ArrayOfBusiness busyArray = gson.fromJson(jsonString,ArrayOfBusiness.class);
				List<Business> theStuff = busyArray.getBusinesses();
				JsonArray finalJarrArray = new JsonArray();
				for (Business x: theStuff) {
					
					String name = x.getName();
					String addy = x.getLocation();
					name = name.replaceAll("u0026", "&");
					name = name.replaceAll("001", "");
					System.out.println(name);
					name = name.replaceAll("\\s+", "_");
					name = name.replaceAll("’", "");
					addy = addy.replaceAll("\\s+", "_");
					addy = addy.replaceAll("’", "");
					String search = "https://api.yelp.com/v3/businesses/search";
					String find = "?term='"+ name + "'&location='" +addy+"'";
					String url = search+find;
					
					System.out.println(url);
						
						request.setAttribute("url", url);
						HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
						
						// optional default is GET
						connection.setRequestMethod("GET");
						connection.setRequestProperty("Authorization",
								"Bearer sibq5OrsQmtSF9g4-FeCGsXdaiCBS6x_5I9RtBnuy0zlel0iip-YN3JQdCpc2PpqDXDRPgEWz4NJMIG-i5KDDTvkjgbbxut9IEh1bWsPuilhNhFKvhrYISh8gSx5XnYx");
						
						BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
						
						String inputLine;
						StringBuffer response1 = new StringBuffer();
						
						while ((inputLine = in.readLine()) != null) {
							response1.append(inputLine);
						}
						
						in.close();

						@SuppressWarnings("deprecation")
						JsonObject jsonObj = new JsonParser().parse(response1.toString()).getAsJsonObject();
//					    		
						JsonArray jArr = jsonObj.get("businesses").getAsJsonArray(); 
						JsonObject jEntry = jArr.get(0).getAsJsonObject();
						finalJarrArray.add(jEntry);
						
						
//					    			
//						
//					    		
				}
				request.setAttribute("username",username);
				request.setAttribute("json",finalJarrArray);
				request.setAttribute("firstArray",true);
				}
				
    	}catch (SQLException e) {
			// TODO Auto-generated catch block
			next="/login-signup.jsp";
			System.out.println("Login: An error occured connecting to database");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	System.out.println("Servlet Complete");
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		dispatch.forward(request,response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
	}

}
