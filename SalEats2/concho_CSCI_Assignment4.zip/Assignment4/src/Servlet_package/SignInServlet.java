package Servlet_package;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import base.ArrayOfBusiness;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignInServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String next = "/home-page.jsp";
    	if(request.getParameter("aJax")!=null) {
    		request.setAttribute("login", false);
    	}
    	else {
    	
    	String username = "";
    	String password="";
    	
    	Connection conn = null;
    	Statement st = null;
    	PreparedStatement ps = null;
    	PreparedStatement ts = null;
    	ResultSet rs = null;
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/SalEats?user=root&password=root&serverTimezone=UTC");
			System.out.println("made connection");
		
			st = conn.createStatement();
			Gson gson = new Gson();
    	
		
		// rs = st.executeQuery("SELECT * from Student where fname='" + name + "'");
		
    	if(request.getParameter("reg-email") != null) {
    		String email = request.getParameter("reg-email");
    		username = request.getParameter("reg-username");
    		password = request.getParameter("reg-password");
    		System.out.println("Email: " + email + "  User: " + username+"  Pass: " + password);
    		
    		try {
				ps = conn.prepareStatement("SELECT * FROM Users WHERE email ='"+email+"' ");
			
				rs = ps.executeQuery();
				System.out.println("Passed SQL Query");
				if (rs.next()) {
					next= "/login-signin.jsp";
					request.setAttribute("error2", "This User Already Exists! Please try signing in.");
				}
				else {
					System.out.println("Registering user: " + username);
					String send = "{\"businesses\":[]}";
					ps = conn.prepareStatement("INSERT INTO Users (username,password, email,favorites) values ('" + username + "', '"+password+"','"+email+"','"+send+"')");
					ps.executeUpdate();
					request.setAttribute("login", true);
					request.setAttribute("find_user",email);
					request.setAttribute("faves", send);
				}
			
			
			
    		} catch (SQLException e) {
				// TODO Auto-generated catch block
    			System.out.println("Register: Was not able to create new user");
				
			}
    		
    	}
    	
    	else {
    		if(request.getParameter("email_signin") == "") {
    			System.out.println("regular login");
    			
    			username = request.getParameter("username");
        		password = request.getParameter("password");
        		
        		try {
    				ps = conn.prepareStatement("SELECT * FROM Users WHERE username ='"+username +"' and password = '"+password+"'");
    			
    				rs = ps.executeQuery();
    				System.out.println("Passed SQL Query");
    				if (rs.next()) {
    					request.setAttribute("login", true);
    					String faves = rs.getString("favorites");
    					String email = rs.getString("email");
    					request.setAttribute("faves", faves);
    					request.setAttribute("find_user",email);

    				}
    				else {
    					next= "/login-signin.jsp";
    					request.setAttribute("error1", "Username or Password could not be found");
    				}
    			
        		}catch (SQLException e) {
        			// TODO Auto-generated catch block
        			System.out.println("Login: Was not able to login user");
        			
        		}
    		}
    		else {
    			System.out.println("Google login");
    			request.setAttribute("login", true);
    			request.setAttribute("google", true);
    			String email = request.getParameter("email_signin");
    			username = request.getParameter("username");
    			password = "google_signin";
    			request.setAttribute("find_user",email);
    			
    			try {
    				ps = conn.prepareStatement("SELECT * FROM Users WHERE email ='"+email+"' ");
    			
    				rs = ps.executeQuery();
    				System.out.println("Passed SQL Query");
    				if (rs.next()) {
    					System.out.println("User: "+username + " already exists!");
    					String faves = rs.getString("favorites");
    					
    						request.setAttribute("faves", faves);
        					request.setAttribute("find_user",email);
    				}
    				else {
    					System.out.println("We could not find the email: " +email + " so we created a new profile!");
    					System.out.println("User: " + username + "  Email: " + email+ "   Password: " + password);
    					String send =  "{\"businesses\":[]}";
    					ts = conn.prepareStatement("INSERT INTO Users (username,password, email,favorites) values ('" + username + "', '"+password+"','"+email+"','"+send+"')");
    					ts.executeUpdate();
    					request.setAttribute("faves", send);
    					request.setAttribute("find_user",email);
    				}
    			
        		}catch (SQLException e) {
        			// TODO Auto-generated catch block
        			next="/login-signup.jsp";
        			System.out.println("Login: An error occured connecting to database");
        			e.printStackTrace();
        		}
    		}
    	}
    	
    } catch (SQLException e) {
		// TODO Auto-generated catch block
    	System.out.println("An error occured connecting to database");
    	e.printStackTrace();
		
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    	
    }
    	System.out.println("Servlet Complete");
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		dispatch.forward(request,response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
    }
   
}
