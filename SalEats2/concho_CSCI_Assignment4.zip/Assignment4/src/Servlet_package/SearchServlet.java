package Servlet_package;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class SearchServlet
 */
@WebServlet(
		urlPatterns = { "/SearchServlet" }, 
		initParams = { 
				@WebInitParam(name = "best", value = "0"), 
				@WebInitParam(name = "lat", value = "34.05"), 
				@WebInitParam(name = "longitude", value = "-118.24")
		})
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


    public SearchServlet() {
     
    }


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "";
		String next = "";
		if(request.getParameter("lat") !=null) {
		String lat1 = request.getParameter("lat");
		String long1 = request.getParameter("longitude");
		String name = request.getParameter("rest_name");
		
		String sort_by = (String) request.getParameter("detail");
		if ( sort_by == null){
			sort_by = "best_match";
		}
//		QUERY
		 next = "/search-results.jsp";
		
		name = name.replaceAll("\\s+", "_");
		String name2 = name.replaceAll("’", "");
		String term = "?term=" + name2;
		String coords = "&latitude=" + lat1 + "&longitude=" + long1;
		String sort = "&sort_by="+sort_by;
		String search = "https://api.yelp.com/v3/businesses/search";
		 url = search + term + coords +sort;
		}
		else {
			next = "/details.jsp";
			String search = "https://api.yelp.com/v3/businesses/search";
			String find = request.getParameter("info");
			System.out.println(find);
			find = find.replaceAll("\\s+", "_");
			String find2 = find.replaceAll("’", "");
			url = search+find2;
			System.out.println(find2);
			System.out.println(url);
		}
		try {
			
				request.setAttribute("url", url);
				HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
				
				// optional default is GET
				connection.setRequestMethod("GET");
				request.setAttribute("enter", "flag: 0");
				connection.setRequestProperty("Authorization",
						"Bearer sibq5OrsQmtSF9g4-FeCGsXdaiCBS6x_5I9RtBnuy0zlel0iip-YN3JQdCpc2PpqDXDRPgEWz4NJMIG-i5KDDTvkjgbbxut9IEh1bWsPuilhNhFKvhrYISh8gSx5XnYx");
				request.setAttribute("enter", "flag: 1");
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				request.setAttribute("enter", "flag: 2");
				int responseCode = connection.getResponseCode();
				request.setAttribute("enter", "flag: 3");
				String inputLine;
				StringBuffer response1 = new StringBuffer();
				request.setAttribute("enter", "yes1");
				while ((inputLine = in.readLine()) != null) {
					response1.append(inputLine);
					request.setAttribute("errorOrder2", inputLine);
				}
				
				in.close();

				@SuppressWarnings("deprecation")
				JsonObject jsonObj = new JsonParser().parse(response1.toString()).getAsJsonObject();
				request.setAttribute("rere", response1.toString());
//			    			
				//JsonArray jArr = jsonObj.get("businesses").getAsJsonArray(); <------ use in search.jsp
				request.setAttribute("json",jsonObj);
				
//			    			
//				JsonObject jEntry = jArr.get(0).getAsJsonObject();
//			    			


		} catch (MalformedURLException e) {
			System.out.println("There seems to have been a problem with the Business Name. Please try an appropriate order.");
			String e1 = "Error: "+e;
			request.setAttribute("errorOrder", e1);
		} catch (IOException e) {
			System.out.println("There seems to have been a problem with the Business Name. Please try an appropriate order.");
			String e1 = "Error: "+e;
			request.setAttribute("errorOrder", e1);
		}
		System.out.println("success!");
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		dispatch.forward(request,response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}
	

}
